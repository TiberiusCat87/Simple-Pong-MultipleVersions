﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimplePong
{
    public partial class Form1 : Form
    {
        // Declare variables
        Rectangle paddle;
        Rectangle paddle2;
        Rectangle ball;

        int paddleSpeed = 20;
        int ballX = 4;
        int ballY = 4;

        // Scoring
        int score1 = 0;
        int score2 = 0;

        // Score to win
        int win = 10;

        // Timer
        Timer gameTimer = new Timer();
        public Form1()
        {
            InitializeComponent();

            // Setup Form
            this.Width = 600;
            this.Height = 400;
            this.Text = "CPU vs User Pong v1";
            this.BackColor = Color.Black;
            this.DoubleBuffered = true;

            // Create a rectangular pattern
            paddle = new Rectangle(this.ClientSize.Width / 2 - 40, this.ClientSize.Height - 20, 80, 10);
            paddle2 = new Rectangle(this.ClientSize.Width / 2 - 40, this.ClientSize.Height - 351, 80, 10);

            // Create a ball
            ball = new Rectangle(this.ClientSize.Width / 2, this.ClientSize.Height / 3, 15, 15);

            // Timer
            gameTimer.Interval = 20; // Update 50 times/second
            gameTimer.Tick += GameLoop;
            gameTimer.Start();

            // Paint Event - Draws Paddle and Ball
            this.Paint += DrawGame;
        }
        private void GameLoop(object sender, EventArgs e)
        {
            // Ball Movement
            ball.X += ballX;
            ball.Y += ballY;
            /* if (ball.X % 2 == 0) Old CPU code
            {
                paddle2.X = ball.X - 35;
            } */

            // CPU Paddle - AI tracks the ball
            if (paddle2.X + paddle2.Width / 2 < ball.X + 10 && paddle2.X + paddle2.Width / 2 > ball.X - 10) // Stop range
                paddle2.X += 0;
            else if (ball.X + ball.Width / 2 < paddle2.X + paddle2.Width / 2 && paddle2.Left > 0)
                paddle2.X -= (paddleSpeed / 2);
            else if (ball.X + ball.Width / 2 > paddle2.X + paddle2.Width / 2 && paddle2.Right < this.ClientSize.Width)
                paddle2.X += (paddleSpeed / 2);
            // Bounce off left/right walls
            if (ball.Left <= 0 || ball.Right >= this.ClientSize.Width)
            {
                ballX = -ballX;
            }

            // Bounce off top
            

            // Check Paddle Collision
            if (ball.IntersectsWith(paddle) || ball.IntersectsWith(paddle2)) // Increases ball speed when hit by either player
            {
                ballX = ballX + 0;
                if (ballY < 10 && ballY > -10) // If ball speed is less than 10
                {
                    if (ballY > 0) // Increase based on direction
                    {
                        ballY = ballY + 1;
                    }
                    else
                    {
                        ballY = ballY - 1;
                    }
                }
                ballY = -ballY;
            }

            // Miss ball
            if (ball.Bottom >= this.ClientSize.Height)
            {
                if (ball.IntersectsWith(paddle) && (paddle.X < ball.X || paddle.X > ball.X + 40)) // Enchanced collison
                {
                    ballX = -ballX;
                }
                else 
                {
                    score2++; // Paddle bottom loses
                    ball.X = this.ClientSize.Width / 2; // Reset ball
                    ball.Y = this.ClientSize.Height / 2;
                
                    this.Text = "CPU vs User Pong v1 | Score: " + score1+" - "+score2; // Score
                    ballY = -4; // Ball speed resets
                }
            }

            // Miss ball top
            if (ball.Top <= 0)
            {
                if (ball.IntersectsWith(paddle) && (paddle.X < ball.X || paddle.X > ball.X + 40)) // Enchanced collison
                {
                    ballX = -ballX;
                }
                else
                {
                score1++; // Paddle top loses
                ball.X = this.ClientSize.Width / 2; // Reset ball
                ball.Y = this.ClientSize.Height / 2;

                this.Text = "CPU vs User Pong v1 | Score: " + score1 + " - " + score2; // Score
                ballY = 4; // Ball speed resets
                }
            }

            if (score1 >= win) // Player 1 wins
            {
                gameTimer.Stop();
                MessageBox.Show("Player 1 wins! | Score: " + score1 + " - " + score2);
            }
            if (score2 >= win) // Player 2 wins
            {
                gameTimer.Stop();
                MessageBox.Show("Player 2 wins! | Score: " + score1 + " - " + score2);
            }

            Invalidate();
        }

        private void DrawGame(object sender, PaintEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.Aqua, paddle);
            e.Graphics.FillRectangle(Brushes.Aqua, paddle2);
            e.Graphics.FillEllipse(Brushes.Red, ball);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Left && paddle.Left > 0) // Player 1 movements
            {
                paddle.X -= paddleSpeed;
            }

            else if (keyData == Keys.Right && paddle.Right < ClientSize.Width)
            {
                paddle.X += paddleSpeed;
            }

            if (keyData == Keys.A && paddle2.Left > 0) // Player 2 movements
            {
                paddle2.X -= paddleSpeed;
            }

            else if (keyData == Keys.D && paddle2.Right < ClientSize.Width)
            {
                paddle2.X += paddleSpeed;
            }


            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
